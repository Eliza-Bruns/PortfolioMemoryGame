# Memory Game Project

  By Elizabeth Brunsman
  For Udacity Front-End Nanodegree Program

## How the Game was Created

  The game was created based on the Udacity starter template (https://github.com/udacity/fend-project-memory-game) and written in HTML, CSS and JavaScipt.

## How to Play

   1. Click a card to open. Open two cards in attempt to find a match. If the cards match they will turn green and remain open and if they do not the cards will remain blue and close.
   2. The timer will start after you have opened two cards. The timer will stop after all cards have been matched or if the restart button has been clicked.
   3. Every attempt to match two cards will count as a move. As you make more moves you will lose stars. Remember the positions of the cards you have opened and work to make the least amount of moves to retain your stars.
   4. When all cards are matched you win the game and popup will display your time, moves and star rating. Choose to play again to beat your time and star rating.

## Why play

  Workout your brain and memory by trying to make the least amount of moves in a short amount of time.

  Good luck & have fun!
