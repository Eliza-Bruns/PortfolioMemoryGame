


/*
 * Display the cards on the page
 *   - shuffle the list of cards using the provided "shuffle" method below
 *   - loop through each card and create its HTML
 *   - add each card's HTML to the page
 */
// Shuffle function from http://stackoverflow.com/a/2450976
const deck = document.querySelector('.deck');
let card = document.getElementsByClassName("card");
let cards = [...card];
let toggledCards = [];
let moves = 0;
let counter = document.querySelector(".moves");
const stars = document.querySelectorAll(".fa-star");
let starsList = document.querySelectorAll(".stars li");
let closeicon = document.querySelector(".close");
let matched = 0;
const Total_Pairs = 8;

// Toggle for modal Popup
function toggleModal() {
  const modal = document.querySelector(".modal__background");
  modal.classList.toggle('hide');
}

toggleModal(); // Open modal
toggleModal(); // Close modal

// Shuffle function
function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }
  return array;
}

// Open & close card when clicked allowing only 2 cards to be opened at a time
function toggleCard(card) {
  card.classList.toggle('open');
  card.classList.toggle('show');
}

function addToggleCard(clickTarget) {
  toggledCards.push(clickTarget);
  console.log(toggledCards);
}

function isClickValid(clickTarget) {
  return (
    clickTarget.classList.contains('card') &&
    !clickTarget.classList.contains('match') &&
    toggledCards.length < 2 &&
    !toggledCards.includes(clickTarget)
  );
}

// Start game with shuffled deck window loads
window.onload = startGame();

function startGame(){
   var shuffledCards = shuffle(cards);
   toggledCards = [];

   for (var i= 0; i < shuffledCards.length; i++){
      deck.innerHTML = "";
      [].forEach.call(shuffledCards, function(item){
         deck.appendChild(item);
      });
      cards[i].classList.remove("show", "open", "match", "disabled");
 }
   moves = 0;
   counter.innerHTML = moves;
   for (var i= 0; i < stars.length; i++){
    stars[i].style.color = "#FFD700";
    stars[i].style.visibility = "visible";
}
  second = 0;
  minute = 0;
  hour = 0;
  var timer = document.querySelector(".timer");
  timer.innerHTML = "0 mins 0 secs";
  clearInterval(interval);
  matched = 0;
}


//Checking for two cards open to be matched
deck.addEventListener('click', event => {
  const clickTarget = event.target;
  if (isClickValid(clickTarget)) {
      toggleCard(clickTarget);
      addToggleCard(clickTarget);
      if (toggledCards.length === 2) {
        addMove();
        checkForMatch(clickTarget);
      }
    }
});

//Function to check for matched cards
function checkForMatch() {
  if (
    toggledCards[0].firstElementChild.className ===
    toggledCards[1].firstElementChild.className
  ) {
    toggledCards[0].classList.toggle('match');
    toggledCards[1].classList.toggle('match');
    toggledCards = [];
    matched++;
  } else {
    setTimeout(() => {
    toggleCard(toggledCards[0]);
    toggleCard(toggledCards[1]);
    toggledCards = [];
  }, 1000);
};
console.log (matched);
gameOver();
}

//Function to add moves and/or lose stars on score board. Each move is two card flips
function addMove() {
  moves++;
  const movesText = document.querySelector('.moves');
  movesText.innerHTML = moves;


  if(moves == 1){
      second = 0;
      minute = 0;
      hour = 0;
      startTimer();
  }

  if (moves > 14 && moves < 19){
    for( i= 0; i < 3; i++){
        if(i > 1){
            stars[i].style.visibility = "collapse";
        }
    }
}
else if (moves > 20){
    for( i= 0; i < 3; i++){
        if(i > 0){
            stars[i].style.visibility = "collapse";
        }
    }
}
}

// Stop and Start timer on scoreboard
var second = 0, minute = 0;
var timer = document.querySelector(".timer");
var interval;
function startTimer(){
    interval = setInterval(function(){
        timer.innerHTML = minute+"mins "+second+"secs";
        second++;
        if(second == 60){
            minute++;
            second = 0;
        }
        if(minute == 60){
            hour++;
            minute = 0;
        }
    },1000);
}

function stopTimer() {
  clearInterval(interval);
}

/*function getStars() {
  stars = document.querySelectorAll('.stars li');
  starCount = 0;
  for (star of stars) {
    if (star.style.display !== 'none') {
      starCount++;
    }
  }
  console.log(starCount);
  return starCount;
}*/


// Function to pull stats when all cards are paired
function writeModalStats() {
  var starRating = document.querySelector(".stars").innerHTML;
  finalTime = timer.innerHTML
  document.getElementById("finalMove").innerHTML = moves;
  document.getElementById("starRating").innerHTML = starRating;
  document.getElementById("totalTime").innerHTML = finalTime;
}


// checking for 8 pairs to end game
function gameOver() {
  if (matched == Total_Pairs) {
    stopTimer();
    writeModalStats();
    toggleModal();
  }
}

// Click to exit Modal without reset
document.querySelector('.modal__cancel').addEventListener('click', () => {
  toggleModal();
});

//Click to exit Modal and Play again
document.querySelector('.modal__replay').addEventListener('click', () => {
  toggleModal();
  startGame();
});
